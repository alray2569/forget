/* global PS: false */

var gameMode;

var BATTLEMODE = {
	enterMode: function (lastState) {
		this.lastState = lastState;
	},
	click: function (x, y, data, options) {
		
	},
	release: function (x, y, data, options) {
		
	},
	enterBead: function (x, y, data, options) {
		
	},
	exitBead: function (x, y, data, options) {
		
	},
	keyDown: function (key, shift, ctrl, options) {
		
	},
	keyUp: function (key, shift, ctrl, options) {
		
	}
};